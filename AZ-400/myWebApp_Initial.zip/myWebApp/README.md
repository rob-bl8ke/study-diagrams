# Genesis

```powershell
mkdir myWebApp
cd myWebApp
```

```
git init
```
Configure global (or local) settings for the name and email address to be used when committing in this Git repository:

```bash
# Rather go local
git config --local user.name "John Doe"
git config --local user.email "john.doe@contoso.com"

# But this is the global version
git config --global user.name "John Doe"
git config --global user.email "john.doe@contoso.com"
```

```bash
git config --global http.proxy
http://proxyUsername:proxyPassword@proxy.server.com:port
```
If you are working behind an enterprise proxy, you can make your Git repository proxy-aware by adding the proxy details in the Git global configuration file.

Different variations of this command will allow you to set up an HTTP/HTTPS proxy (with username/password) and optionally bypass SSL verification.

Run the below command to configure a proxy in your global git config.

```bash
git config --global http.proxy
http://proxyUsername:proxyPassword@proxy.server.com:port
```
Create a new ASP.NET core application. The new command offers a collection of switches that can be used for language, authentication, and framework selection. More details can be found on Microsoft docs.

```bash
dotnet new mvc
```

Launch Visual Studio Code in the context of the current-working folder:

```bash
code .
```

If you prefer to use the command line, you can run the following commands in the context of the git repository to run the web application.

```bash
dotnet build
dotnet run
```

### Add the `.gitignore` File

You will notice the ".vscode" folder is added to your working folder. To avoid committing this folder to your Git repository, you can include it in the `.gitignore` file. Select a file from the ".vscode" folder, hit F1 to launch the command window in Visual Studio Code, type gitIgnore, and accept the option to include the selected file in the new `.gitIgnore` file.

To ignore an entire directory, you need to include the name of the directory with the slash / at the end. Open your ``.gitignore``, remove the file name from the path, and leave the folder with a slash, for example, .vscode/*.

```
.vscode/*
```



